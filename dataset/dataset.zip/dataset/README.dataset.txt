# undefined > 2022-04-20 1:57pm
https://public.roboflow.ai/classification/undefined

Provided by undefined
License: CC BY 4.0

undefined