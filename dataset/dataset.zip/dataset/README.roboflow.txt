
WRM - v1 2022-04-20 1:57pm
==============================

This dataset was exported via roboflow.ai on April 20, 2022 at 10:57 AM GMT

It includes 480 images.
Eyes are annotated in Multi-Class Classification format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 224x224 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -10 and +10 degrees
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically


